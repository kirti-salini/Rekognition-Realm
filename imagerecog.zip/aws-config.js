// aws-config.js

// // Load environment variables
// const AWS_ACCESS_KEY_ID = process.env.AWS_ACCESS_KEY_ID;
// const AWS_SECRET_ACCESS_KEY = process.env.AWS_SECRET_ACCESS_KEY;

// Configure AWS SDK
AWS.config.update({
    accessKeyId: 'AKIAXYKJQ4P6EOO2QCHI',
    secretAccessKey: '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',
    region: 'ap-south-1'
});
